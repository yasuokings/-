# Jade(Pug) Parser

Read more about its syntax at: https://github.com/iris-contrib/jade.

Fixes:

- https://github.com/iris-contrib/jade/issues/33
- https://github.com/kataras/iris/issues/1450
