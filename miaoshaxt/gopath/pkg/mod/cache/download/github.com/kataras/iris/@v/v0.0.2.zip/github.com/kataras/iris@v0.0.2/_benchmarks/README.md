# Benchmarks

Moved to <https://github.com/kataras/server-benchmarks#benchmarks>.
