# Set Custom Functions

This example shows how to set custom functions.
