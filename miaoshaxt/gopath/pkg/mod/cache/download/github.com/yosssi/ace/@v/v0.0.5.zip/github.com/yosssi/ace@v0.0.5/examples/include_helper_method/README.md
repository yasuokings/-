# Include Helper Method

This example shows how to use an include helper method.
