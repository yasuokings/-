# Projects using Ace

* [Ace Proxy](https://github.com/yosssi/ace-proxy) - Proxy for the Ace template engine
* [ace.yoss.si](https://github.com/yosssi/ace.yoss.si) - Website of Ace
* [Martini Acerender](https://github.com/yosssi/martini-acerender) - Martini middleware/handler for parsing Ace templates and rendering HTML
* [Hugo](https://github.com/spf13/hugo) - Static Site Generator written in Go
* [ace-util](https://github.com/catinello/ace-util) - Command line utility for the Ace HTML template engine.
