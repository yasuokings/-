// Package ace provides an HTML template engine.
package ace
