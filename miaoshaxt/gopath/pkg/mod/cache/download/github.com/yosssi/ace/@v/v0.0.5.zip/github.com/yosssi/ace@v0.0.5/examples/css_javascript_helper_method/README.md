# CSS and Javascript Helper Method

This example shows how to use the css and javascript helper method.
