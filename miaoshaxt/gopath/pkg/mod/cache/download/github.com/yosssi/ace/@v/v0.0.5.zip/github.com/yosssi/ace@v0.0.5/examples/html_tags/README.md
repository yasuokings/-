# HTML Tags

This example shows how to generate various HTML tags.
